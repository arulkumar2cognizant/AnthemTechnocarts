﻿using System;
using Microsoft.ML;
using Microsoft.ML.Data;
using Microsoft.ML.Runtime.Api;
using Microsoft.ML.Trainers;
using Microsoft.ML.Transforms;
using System.Collections.Generic;

using System.Windows.Forms;
using System.Collections;

namespace ClaimDecisionMaking
{
   
    public partial class Form1 : Form
    {
        

        public Form1()
        {
            InitializeComponent();
        }

        private void LoadICDCode()
        {
            try
            {
                List<ComboModel> icd = new List<ComboModel>();
                ComboModel ComboModel = new ComboModel() {Value=1,Displaytext= "Chennai" };
                icd.Add(ComboModel);
                ComboModel = new ComboModel() { Value = 2, Displaytext = "Coimbatore" };
                icd.Add(ComboModel);
                ComboModel = new ComboModel() { Value = 3, Displaytext = "Bangalore" };
                icd.Add(ComboModel);
                ComboModel = new ComboModel() { Value = 4, Displaytext = "Ooty" };
                icd.Add(ComboModel);
                ComboModel = new ComboModel() { Value = 5, Displaytext = "Delhi" };
                icd.Add(ComboModel);
                ComboModel = new ComboModel() { Value = 6, Displaytext = "Hydrabad" };
                icd.Add(ComboModel);
                cmbIcdcode.DataSource = icd;
                cmbIcdcode.DisplayMember = "Displaytext";
                cmbIcdcode.ValueMember = "Value";
            }
            catch (Exception)
            {

                throw;
            }
        }
        
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string High = "High";
                string Noromal = "Normal";
                string Dry = "Dry";
                // string denied = "Denied";
                lblresult.Text = string.Empty;
                lblresult.Visible = false;
                Cursor.Current = Cursors.WaitCursor;
                string ageGenderResult = string.Empty;
                string ageGenderProcessInfo = string.Empty;
                string treatmentResult = string.Empty;
                string treatmentProcessInfo = string.Empty;
                string pharmacyresult = string.Empty;


                //Console.WriteLine($"Predicted flower type is: {prediction.PredictedLabels}");
                //Console.ReadLine();
                #region age-wise learning
                var pipeline = new LearningPipeline();

                // If working in Visual Studio, make sure the 'Copy to Output Directory' 
                // property of iris-data.txt is set to 'Copy always'
                //string dataPath = "age-gender-data.txt";
                //pipeline.Add(new TextLoader(dataPath).CreateFrom<IrisData>(separator: ','));

                // STEP 3: Transform your data
                // Assign numeric values to text in the "Label" column, because only
                // numbers can be processed during model training
               // pipeline.Add(new Dictionarizer("Label"));

                // Puts all features into a vector
               // pipeline.Add(new ColumnConcatenator("Features", "ICD", "Age", "Gender"));

                // STEP 4: Add learner
                // Add a learning algorithm to the pipeline. 
                // This is a classification scenario (What type of iris is this?)
              //  pipeline.Add(new StochasticDualCoordinateAscentClassifier());

                // Convert the Label back into original text (after converting to number in step 3)
               // pipeline.Add(new PredictedLabelColumnOriginalValueConverter() { PredictedLabelColumn = "PredictedLabel" });

                // STEP 5: Train your model based on the data set
               // var model = pipeline.Train<IrisData, IrisPrediction>();

                // STEP 6: Use your model to make a prediction
                // You can change these numbers to test different predictions
                float icd = float.Parse(cmbIcdcode.SelectedValue.ToString());
                float age = float.Parse(txtAge.Text.ToString());
                //float gender = float.Parse(cmbgender.SelectedValue.ToString());

                //var prediction = model.Predict(new IrisData()
                //{
                //    ICD = icd,
                //    Age = age,
                //    Gender = gender,

                //});
                //ageGenderResult = prediction.PredictedLabels;
                #endregion
                //ageGenderProcessInfo = $"Age,Gender and ICD based: {prediction.ToString()}";
                //Console.WriteLine($"Predicted flower type is: {prediction.PredictedLabels}");
                //Console.ReadLine();

                //#region treatment-amount

                //var pipelineTreatment = new LearningPipeline();

                //// If working in Visual Studio, make sure the 'Copy to Output Directory' 
                //// property of iris-data.txt is set to 'Copy always'
                //string dataPathTreatment = "treatmentdata.txt";
                //pipelineTreatment.Add(new TextLoader(dataPathTreatment).CreateFrom<TreatmentAmount>(separator: ','));

                //// STEP 3: Transform your data
                //// Assign numeric values to text in the "Label" column, because only
                //// numbers can be processed during model training
                //pipelineTreatment.Add(new Dictionarizer("Label"));

                //// Puts all features into a vector
                //pipelineTreatment.Add(new ColumnConcatenator("Features", "ICD", "Amount"));

                //// STEP 4: Add learner
                //// Add a learning algorithm to the pipeline. 
                //// This is a classification scenario (What type of iris is this?)
                //pipelineTreatment.Add(new StochasticDualCoordinateAscentClassifier());

                //// Convert the Label back into original text (after converting to number in step 3)
                //pipelineTreatment.Add(new PredictedLabelColumnOriginalValueConverter() { PredictedLabelColumn = "PredictedLabel" });

                //// STEP 5: Train your model based on the data set
                //var modelTreatment = pipelineTreatment.Train<TreatmentAmount, IrisPrediction>();

                //// STEP 6: Use your model to make a prediction
                //// You can change these numbers to test different predictions

                //float treatmentAmount = float.Parse(txtTreatmentamount.Text.ToString());

                //var predictionTreatment = modelTreatment.Predict(new TreatmentAmount()
                //{
                //    ICD = icd,
                //    Amount = treatmentAmount,

                //});
                //treatmentResult = predictionTreatment.PredictedLabels;
                //#endregion


                #region pharmacy-amount
                //var pipelineTreatment = new LearningPipeline();
                var pipelinePharmacy = new LearningPipeline();
                NewMethod(pipelinePharmacy);

                // STEP 3: Transform your data
                // Assign numeric values to text in the "Label" column, because only
                // numbers can be processed during model training
                pipelinePharmacy.Add(new Dictionarizer("Label"));

                // Puts all features into a vector
                pipelinePharmacy.Add(new ColumnConcatenator("Features", "ICD", "Amount"));

                // STEP 4: Add learner
                // Add a learning algorithm to the pipeline. 
                // This is a classification scenario (What type of iris is this?)
                pipelinePharmacy.Add(new StochasticDualCoordinateAscentClassifier());

                // Convert the Label back into original text (after converting to number in step 3)
                pipelinePharmacy.Add(new PredictedLabelColumnOriginalValueConverter() { PredictedLabelColumn = "PredictedLabel" });

                // STEP 5: Train your model based on the data set
                var modelPharmacy = pipelinePharmacy.Train<TreatmentAmount, IrisPrediction>();

                // STEP 6: Use your model to make a prediction
                // You can change these numbers to test different predictions

                float PharmacyAmount = float.Parse(txtAge.Text.ToString());

                var pharmacyTreatment = modelPharmacy.Predict(new TreatmentAmount()
                {
                    ICD = icd,
                    Amount = age,

                });
                pharmacyresult = pharmacyTreatment.PredictedLabels;
                #endregion


                //var treatmentResultData = treatmentResult.Split('-');
                //string treatmentResultOutcome = treatmentResultData.Length > 0 ? treatmentResultData[treatmentResultData.Length - 1] : "";

                var pharmacyResultData = pharmacyresult.Split('-');
                string pharmacyResultOutcome = pharmacyResultData.Length > 0 ? pharmacyResultData[pharmacyResultData.Length - 1] : "";

                if (pharmacyResultOutcome.ToUpper() == High.ToUpper())
                {
                    lblresult.Text = "city water level is more adequate";
                    lblresult.ForeColor = System.Drawing.Color.Green;
                }
                else if (pharmacyResultOutcome.ToUpper() == Noromal.ToUpper())
                {
                    lblresult.Text = "city water level is adequate ";
                    lblresult.ForeColor = System.Drawing.Color.Yellow;
                }
                else
                {
                    lblresult.Text = "City water level is not adequate";
                    lblresult.ForeColor = System.Drawing.Color.Red;
                }
                lblresult.Visible = true;
                //lblresult.Text += "---" + pharmacyresult;


            }
            catch (Exception)
            {
                lblresult.Text = "In valid inputs";
                lblresult.ForeColor = System.Drawing.Color.Red;
                lblresult.Visible = true;
                //throw;
            }
            finally
            {
                lblresult.Visible = true;
                Cursor.Current = Cursors.Default;
            }
        }

        private static void NewMethod(LearningPipeline pipelinePharmacy)
        {

            // If working in Visual Studio, make sure the 'Copy to Output Directory' 
            // property of iris-data.txt is set to 'Copy always'
            string dataPathPharmacy = "trainedhistoricwaterleveldata.txt";
            pipelinePharmacy.Add(new TextLoader(dataPathPharmacy).CreateFrom<TreatmentAmount>(separator: ','));
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            LoadICDCode();
           
            lblresult.Visible = false;
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }

    public class ComboModel
    {
        public int Value { get; set; }
        public string Displaytext { get; set; }
    }
    public class IrisData
    {
        [Column("0")]
        public float ICD;

        [Column("1")]
        public float Age;

        [Column("2")]
        public float Gender;

        [Column("3")]
        [ColumnName("Label")]
        public string Label;
    }
    public class TreatmentAmount
    {
        [Column("0")]
        public float ICD;

        [Column("1")]
        public float Amount;

        [Column("2")]
        [ColumnName("Label")]
        public string Label;
    }

    public class IrisPrediction
    {
        [ColumnName("PredictedLabel")]
        public string PredictedLabels;
    }

}
